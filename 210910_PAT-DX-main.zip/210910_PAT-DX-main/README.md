> 21.09.10 PAT-DX 공유자료

- 첨부
  - Day02.r


- 장표
  - A1. 머신러닝 Intro
  - A2. 선형회귀
  - A3. RF
  - A4. 다중회귀
  - A5. 머신러닝 심화
  - I1. MSE
  - I2. Confusion Matrix
  - I3. ROCR
  - 실습 1. IVF-M HP pH 측정 간소화를 통한 공정시간 단축 및 GMP 리스크 감소
  - 실습 2. 공정용 소모품 사용 예측 수준 증대를 통한 낭비비용 절감


- Data
  - consume.rds
  - LGDatasets_sales.csv
